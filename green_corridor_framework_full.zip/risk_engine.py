import yaml

# Simulate CMDB with mock file
def load_cmdb_mock(cmdb_path='cmdb_mock.yaml'):
    with open(cmdb_path, 'r') as f:
        return yaml.safe_load(f)

# Determine risk based on CMDB or fallback logic
def determine_risk(component_name, cmdb_data):
    component = cmdb_data.get('components', {}).get(component_name)
    if not component:
        print(f"[RiskEngine] No CMDB entry found for {component_name}. Prompting user fallback.")
        return 'Ask'

    sensitivity = component.get('data_sensitivity', 'unknown')
    exposure = component.get('user_access', 'internal')

    # Example logic: High risk = sensitive + external
    if sensitivity == 'high' and exposure == 'external':
        return 'High'
    elif sensitivity == 'medium':
        return 'Medium'
    else:
        return 'Low'

# Return controls to enforce based on risk level
def get_controls_for_risk(risk_level, config_risks):
    for r in config_risks:
        if r['level'].lower() == risk_level.lower():
            return r['required_controls']
    return []