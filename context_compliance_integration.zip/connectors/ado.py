def fetch_ado_data():
    print("Mock fetch from Azure DevOps API")
    # Simulate fetching repos and pipeline runs
    return {"repos": ["service-a", "service-b"], "pipelines": ["build", "release"]}