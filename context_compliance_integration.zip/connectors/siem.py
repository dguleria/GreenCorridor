def fetch_siem_data():
    print("Mock fetch from SIEM system")
    # Simulate pulling alert events
    return {"alerts": [{"id": 1, "severity": "high", "source": "App1"}]}