def fetch_appsec_data():
    print("Mock fetch from AppSec scanner")
    # Simulate fetching SAST results
    return {"vulnerabilities": [{"id": "VULN-123", "severity": "medium"}]}