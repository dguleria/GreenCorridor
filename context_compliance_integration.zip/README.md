# Context and Compliance Integration System

## Overview
This solution integrates Azure DevOps (ADO), SIEM, AppSec Scanning, and Risk Management systems to provide a unified context for compliance tracking.

## Components
- **ADO Connector**: Fetches pipeline and repo metadata.
- **SIEM Connector**: Pulls relevant security events.
- **AppSec Scanner Connector**: Retrieves scan results.
- **Risk System Connector**: Gathers compliance/risk data.

## Setup Instructions

### Requirements
- Docker
- Python 3.10+
- API keys or credentials for each tool

### Running the System
1. Update `.env` with your API keys.
2. Build and run the Docker container:
   ```bash
   docker build -t context-integrator .
   docker run --env-file .env context-integrator
   ```

### Notes
- Sample mock connectors provided. Replace with actual API integrations.
- Outputs stored in `/data/output/`.