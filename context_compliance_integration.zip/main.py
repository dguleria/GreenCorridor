from connectors.ado import fetch_ado_data
from connectors.siem import fetch_siem_data
from connectors.appsec import fetch_appsec_data
from connectors.risk import fetch_risk_data

def main():
    print("Fetching ADO Data...")
    fetch_ado_data()
    
    print("Fetching SIEM Events...")
    fetch_siem_data()
    
    print("Fetching AppSec Scans...")
    fetch_appsec_data()
    
    print("Fetching Risk System Data...")
    fetch_risk_data()

    print("All data fetched and correlated.")

if __name__ == "__main__":
    main()